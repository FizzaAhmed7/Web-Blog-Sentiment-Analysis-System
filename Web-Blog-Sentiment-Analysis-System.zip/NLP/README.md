# NLPCompanion

A simple NLP project that fetches blogs, generates human-like comments, and analyzes sentiment.

## Workflow
1. Enter a keyword.
2. Choose how many blogs to fetch.
3. Fetch top Medium blogs.
4. Clean and preprocess content.
5. Auto-generate short comments.
6. Analyze sentiment.
7. Display results as a pie chart.
