from serpapi import GoogleSearch
import requests
import time

def fetch_blogs(keyword, limit=50):
    print(f"Searching blogs for keyword: {keyword}")
    api_key = "cdeb07f7788d042eb235b1ed80955a571c15ddc63a9f200213d1faaa85a71350"
    blogs = []

    # Cap limit between 10 and 99
    limit = max(10, min(limit, 99))

    for start in range(0, limit, 10):
        params = {
            "engine": "google",
            "q": f"{keyword} blog",
            "api_key": api_key,
            "num": 10,
            "start": start
        }

        try:
            search = GoogleSearch(params)
            results = search.get_dict()

            organic_results = results.get("organic_results", [])
            if not organic_results:
                print(f"No more results at offset {start}.")
                break

            for item in organic_results:
                title = item.get("title", "")
                link = item.get("link", "")

                # Check if already added
                if title and link and not any(b["url"] == link for b in blogs):
                    # Test if URL is reachable (timeout 15 sec)
                    try:
                        response = requests.head(link, timeout=15)
                        if response.status_code < 400:
                            blogs.append({"title": title, "url": link})
                            print(f"Added: {title}")
                        else:
                            print(f"Skipped (bad status): {link}")
                    except Exception as e:
                        print(f"Skipped (timeout/error): {link} -> {e}")

                    if len(blogs) >= limit:
                        break

            # avoid hitting SerpApi rate limit
            time.sleep(1)

        except Exception as e:
            print(f"Error fetching batch starting at {start}: {e}")
            break

        if len(blogs) >= limit:
            break

    print(f"\nFetched {len(blogs)} working blogs successfully.")
    return blogs
