import re
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
import nltk

# Download stopwords if not already present
nltk.download('stopwords', quiet=True)

def clean_and_tokenize(html_content):
    text = BeautifulSoup(html_content, 'html.parser').get_text()
    text = re.sub(r'[^A-Za-z\s]', '', text)  # keep only letters
    text = text.lower()
    tokens = text.split()

    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words and len(word) > 2]

    return tokens, ' '.join(tokens)