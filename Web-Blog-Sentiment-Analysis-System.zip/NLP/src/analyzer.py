from textblob import TextBlob
from collections import Counter

def analyze_sentiment(comments):
    sentiments = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
    word_counter = Counter()

    for c in comments:
        score = TextBlob(c).sentiment.polarity
        if score > 0.1:
            sentiments['Positive'] += 1
        elif score < -0.1:
            sentiments['Negative'] += 1
        else:
            sentiments['Neutral'] += 1

        tokens = c.lower().split()
        word_counter.update(tokens)

    return sentiments, word_counter