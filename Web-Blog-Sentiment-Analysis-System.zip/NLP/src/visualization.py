import matplotlib.pyplot as plt
from wordcloud import WordCloud

def plot_sentiments_and_wordcloud(sentiments, word_counter):
    # --- Sentiment Pie Chart ---
    labels = list(sentiments.keys())
    values = list(sentiments.values())
    colors = ['#9b5de5', '#f15bb5', '#00bbf9']
    explode = [0.08 if v > 0 else 0 for v in values]

    plt.figure(figsize=(14, 6))
    plt.subplot(1, 2, 1)
    plt.pie(values, labels=labels, autopct='%1.1f%%', startangle=90,
            explode=explode, shadow=True, colors=colors,
            textprops={'fontsize': 12, 'color': 'black'})
    plt.title('Sentiment Distribution', fontsize=18, fontweight='bold', pad=25)
    plt.axis('equal')

    # --- Word Cloud ---
    plt.subplot(1, 2, 2)
    wc = WordCloud(width=600, height=400, background_color='white',
                   colormap='plasma', max_words=100).generate_from_frequencies(word_counter)
    plt.imshow(wc, interpolation='bilinear')
    plt.axis('off')
    plt.title('Most Common Comment Keywords', fontsize=18, fontweight='bold')

    plt.tight_layout()
    plt.show()