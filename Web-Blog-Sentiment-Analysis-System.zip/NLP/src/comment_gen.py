import random

def generate_comment(blog_title):
    templates = [
        f"Loved this piece on {blog_title}! Really insightful.",
        f"This blog gave me a new perspective on {blog_title}.",
        f"Amazing content about {blog_title}, keep sharing!",
        f"I enjoyed reading about {blog_title}, great work!"
    ]
    return random.choice(templates)
