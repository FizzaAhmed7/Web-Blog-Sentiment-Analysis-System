from src.fetcher import fetch_blogs
from src.sparser import clean_and_tokenize
from src.comment_gen import generate_comment
from src.analyzer import analyze_sentiment
from src.visualization import plot_sentiments_and_wordcloud
import requests

def main():
    keyword = input("Enter a search keyword (e.g., 'machine learning'): ")

    try:
        limit = int(input("How many blog URLs do you want to fetch? (e.g., 5, 10, 100): "))
    except ValueError:
        limit = 5

    blogs = fetch_blogs(keyword, limit)

    if not blogs:
        print("No blogs found. Try another keyword.")
        return

    comments = []
    all_tokens = []

    for blog in blogs:
        print(f"\nTitle: {blog['title']}")
        print(f"URL: {blog['url']}")
        try:
            html = requests.get(blog['url'], timeout=10).text
            tokens, clean_blog = clean_and_tokenize(html)
            all_tokens.extend(tokens)

            comment = generate_comment(blog['title'])
            comments.append(comment)
            print(f"Generated Comment: {comment}")
        except Exception as e:
            print(f"Error fetching content for {blog['url']}: {e}")

    # Analyze sentiment and word frequencies
    sentiments, word_counter = analyze_sentiment(comments)

    # Display sentiment summary
    print("\nSentiment Summary:", sentiments)

    # Visualization
    plot_sentiments_and_wordcloud(sentiments, word_counter)

if __name__ == "__main__":
    main()